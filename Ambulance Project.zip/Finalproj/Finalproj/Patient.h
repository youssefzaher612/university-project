#pragma once
#include <iostream>
#include "SimulationTime.h"
using namespace std;

class Patient {
private:
    int pid;
    int hid;
    int distance;
    bool picked;
    int request_time;
    int PickupTime;
    int WaitTime;
    int FinishTime;
    int cancelTime;
public:
    Patient() {
        pid = 0;
        hid = 0;
        distance = 0;
        picked = false;
        request_time = -1;
        PickupTime = 0;
        WaitTime = 0;
        FinishTime = 0;
        cancelTime = -1;
    }

    Patient(int request_time, int pid, int hid, int distance) {
        this->pid = pid;
        this->hid = hid;
        this->distance = distance;
        this->request_time = request_time;
        picked = false;

    }
    virtual ~Patient() {}
    void setFinishTime(int ft)
    {
        FinishTime = ft;
    }
    void setWaitTime()
    {
        WaitTime = PickupTime - request_time;
    }
    int getWaitTime() { return WaitTime; }
    void setRequestTime(int request_time) {
        this->request_time = request_time;
    }
    int getRequestTime() const { return request_time; }
    int getFinishTime() { return FinishTime; }
    void setPickupTime(int pt)
    {
        PickupTime = pt;
        WaitTime = PickupTime - request_time;
    }
    int getPickupTime() const
    {
        return PickupTime;
    }
    void setHID(int new_hid) {
        hid = new_hid;
    }
    int getCancelTime() { return cancelTime; }
    void setCancelTime(int n) { cancelTime = n; }


    void setPID(int new_pid) {
        pid = new_pid;
    }

    void setDistance(int new_distance) {
        distance = new_distance;
    }

    void setPicked(bool picked) {
        this->picked = picked;
    }
    

    int getPID() const {
        return pid;
    }
    int getHID() const {
        return hid;
    }
    int getDistance() const {
        return distance;
    }
    bool getPicked() const {
        return picked;
    }

};

class NP : public Patient {
private:
    int cancel_time = -1;
public:
    NP() : Patient() {}
    NP(int request_time, int pid, int hid, int distance)
        : Patient(request_time, pid, hid, distance) {}

    void setCancelTime(int cancel_time) {
        this->cancel_time = cancel_time;
    }
    int getCancelTime() const {
        return cancel_time;
    }
    void print() const {
        cout << "NP " << getRequestTime() << " " << getPID() << " " << getHID() << " " << getDistance();
    }
};

class SP : public Patient {
public:
    SP() : Patient() {}
    SP(int request_time, int pid, int hid, int distance)
        : Patient(request_time, pid, hid, distance) {}

    void print() const {
        cout << "SP " << getRequestTime() << " " << getPID() << " " << getHID() << " " << getDistance();
    }
};

class EP : public Patient {
private:
    int severity;
public:
    EP() : Patient(), severity(0) {}
    EP(int request_time, int pid, int hid, int distance, int severity)
        : Patient(request_time, pid, hid, distance), severity(severity) {}
    void setSeverity(int severity) {
        this->severity = severity;
    }
    int getSeverity() const {
        return severity;
    }
    void print() const {
        cout << "EP " << getRequestTime() << " " << getPID() << " " << getHID() << " " << getDistance() << " " << getSeverity();
    }
};
