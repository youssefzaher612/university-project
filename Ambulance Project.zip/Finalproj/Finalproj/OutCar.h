#pragma once
#include "priQueue.h"

class OutCarsQueue : public priQueue<Car*>
{
public:
    void print() {
        cout << count() << " ==> Out cars: ";
        printCar();
    }
    Car* cancel(int pid) {
        if (isEmpty())
            return nullptr;

        priNode<Car*>* cancelled_car = nullptr;
        int priority;

        // Special case: the car to cancel is at the front
        if (head->getItem(priority)->getPatient()->getPID() == pid) {
            cancelled_car = head;
            head = head->getNext(); // Update head
            counter--; // Decrement counter
            Car* car = cancelled_car->getItem(priority);
            delete cancelled_car; // Free memory
            return car;
        }

        // General case: car is in the middle or end
        priNode<Car*>* delayed_ptr = head;
        priNode<Car*>* moving_ptr = head->getNext();

        while (moving_ptr) {
            if (moving_ptr->getItem(priority)->getPatient()->getPID() == pid) {
                cancelled_car = moving_ptr;
                delayed_ptr->setNext(moving_ptr->getNext()); // Remove the node
                if (!moving_ptr->getNext()) // If the canceled node was the last one
                    delayed_ptr->setNext(nullptr);
                counter--; // Decrement counter
                Car* car = cancelled_car->getItem(priority);
                delete cancelled_car; // Free memory
                return car;
            }
            delayed_ptr = moving_ptr;
            moving_ptr = moving_ptr->getNext();
        }

        return nullptr; // Car not found
    }
};