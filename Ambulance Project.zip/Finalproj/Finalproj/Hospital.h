#pragma once
#include "OutCar.h"
#include "LinkedQueue.h"
#include <iostream>
#include "Patient.h"
#include "Car.h"
#include "SimulationTime.h"
using namespace std;

class Hospital {
public:
    int hospitalID;


    Patient* patient;
    Car* car;
    int FreeNC = 0;
    int FreeSC = 0;

    LinkedQueue<SP*> SPList;
    priQueue<EP*> EPList;
    LinkedQueue<NP*> NPList;



    LinkedQueue<Car*> SCars;
    LinkedQueue<Car*> NCars;
    LinkedQueue <Car*> CheckupList;

    int NCarSpeed;
    int SCarSpeed;
    int hid;
    bool failure = false;
public:
    Hospital() {
        NCarSpeed = 0;
        SCarSpeed = 0;
        hid = 0;
    }

    void setID(int hid) { this->hid = hid; }
    void setFreeNC(int n) { FreeNC = n; }
    void setFreeSC(int n) { FreeSC = n; }
    int getFreeNC() { return FreeNC; }
    int getFreeSC() { return FreeSC; }
    void setFail() {
        failure = true;
    }
    bool GetFail()
    {
        return failure;
    }


    void printCars() {
        cout << "Free Cars: " << SCars.count() << "SCars, " << NCars.count() << "NCars";
    }
    void printAll() {
        EPList.printEP();
        cout << endl;

        SPList.print();
        cout << endl;

        NPList.print();
        cout << endl;

        printCars();
        cout << endl;
    }

    LinkedQueue<NP*> getNPList() const { return NPList; }
    priQueue<EP*> getEPList() const { return EPList; }
    LinkedQueue<SP*> getSPList() const { return SPList; }
    LinkedQueue <Car*>getCheckupList() {
        return CheckupList;
    }


    void addNP(NP* np) {
        if (!np) return;
        NPList.enqueue(np);
    }

    void addSP(SP* sp) {
        if (!sp) return;
        SPList.enqueue(sp);
    }

    void addEP(EP* ep) {
        if (!ep) return;
        EPList.enqueue(ep, ep->getSeverity());
    }

    bool RemoveNP(NP*& np) {
        if (NPList.isEmpty())
        {
            return false;
        }
        else
        {
            NPList.dequeue(np);
            return true;
        }
    }
    bool RemoveSP(SP*& sp) {
        if (SPList.isEmpty())
        {
            return false;
        }
        else
        {
            SPList.dequeue(sp);
            return true;
        }
    }
    bool RemoveEP(EP*& ep) {
        if (EPList.isEmpty())
        {
            return false;
        }
        else
        {
            int sev;
            EPList.dequeue(ep,sev);
            return true;
        }
    }


    void setNCarSpeed(int speed) { NCarSpeed = speed; }
    void setSCarSpeed(int speed) { SCarSpeed = speed; }

    void addNCar(Car* ncar) { 
        if (ncar->GetFail())
        {
            CheckupList.enqueue(ncar);
        }
        else
            NCars.enqueue(ncar);
    }


    void addSCar(Car* scar) { 
        if (scar->GetFail())
        {
            CheckupList.enqueue(scar);
        }
        else
            SCars.enqueue(scar);
    } 


    bool isEmpty()
    {
        return NPList.isEmpty() && SPList.isEmpty() && EPList.isEmpty();
    }
    bool EmptyCars()
    {
        return NCars.isEmpty() && SCars.isEmpty();
    }



    void cancelNP(NP* np)
    {
        NPList.cancel(np->getPID());
    }

    LinkedQueue<Car*>& getNCars() { return NCars; }
    LinkedQueue<Car*>& getSCars() { return SCars; }
    LinkedQueue<NP*>& getNPList() { return NPList; }
    priQueue<EP*>& getEPList() { return EPList; }
    LinkedQueue<SP*>& getSPList() { return SPList; }
    int getHID() const { return hid; }



    Car* AssignPatient() {
        Car* car = nullptr;

        if (!EPList.isEmpty()) {
            EP* ep;
            int pri;

            if (!NCars.isEmpty()) {
                NCars.dequeue(car);            
                EPList.dequeue(ep, pri);      
                car->assignPatient(ep);       
                return car;
            }
            else if (!SCars.isEmpty()) {
                SCars.dequeue(car);           
                EPList.dequeue(ep, pri);     
                car->assignPatient(ep);       
                return car;
            }
        }

        if (!SPList.isEmpty()) {
            SP* sp;

            if (!SCars.isEmpty()) {
                SCars.dequeue(car);           
                SPList.dequeue(sp);          
                car->assignPatient(sp);      
                return car;
            }
        }


        if (!NPList.isEmpty()) {
            NP* np;


            if (!NCars.isEmpty()) {
                NCars.dequeue(car);           
                NPList.dequeue(np);          
                car->assignPatient(np);       
                return car;
            }
        }


        return nullptr;
    }


    int getBusyTime() {
        int TotalTime = 0;
        Node<Car*>* current = NCars.getfrontPtr();
        while (current) {
            TotalTime += current->getItem()->getBusyTime();
            current = current->getNext();
        }
        current = SCars.getfrontPtr();
        while (current) {
            TotalTime += current->getItem()->getBusyTime();
            current = current->getNext();
        }
        return TotalTime;
    }

    int getWaitTime() {
        int TotalTime = 0;
        NP* np;
        SP* sp;
        EP* ep;
        int pri;

        while (!NPList.isEmpty())
        {
            NPList.dequeue(np);
            TotalTime += np->getWaitTime();
        }

        while (!SPList.isEmpty())
        {
            SPList.dequeue(sp);
            TotalTime += sp->getWaitTime();
        }

        while (!EPList.isEmpty())
        {
            EPList.dequeue(ep,pri);
            TotalTime += ep->getWaitTime();
        }

        return TotalTime;
    }
    void CheckUpRetrieve() {
        Car* c;
        while (!CheckupList.isEmpty())
        {
            CheckupList.dequeue(c);

            if (c->gettype() == 0)
            {
                NCars.enqueue(c);
            }
            else if (c->gettype() == 1)
            {
                SCars.enqueue(c);
            }

        }
    }
   
};



