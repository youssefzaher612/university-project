#pragma once
#ifndef ORGANIZER_H
#define ORGANIZER_H

#include "Hospital.h"
#include "Car.h"
#include "LinkedQueue.h"
#include "priQueue.h"
#include "OutCar.h"
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include "Patient.h"
#include <iostream>
using namespace std;

class Organizer {
public:
    int** distanceMatrix;                  
    Hospital** AllHospitals;               
    int numHospitals;                      
    LinkedQueue<Patient*> AllPatients;     
    LinkedQueue<Patient*> CancellationList;
    LinkedQueue<Patient*> FinishedList;
    int scarSpeed, ncarSpeed;              
    priQueue<Car*> BackCars;             
    OutCarsQueue OutCars;                 



    int outcarfail;
    int nooffailedcars = 0;
    int EPfailedNumb = 0;
    int checkuptime;
    LinkedQueue <Car*> CheckupList;
public:
    Organizer() : distanceMatrix(nullptr), AllHospitals(nullptr), numHospitals(0), scarSpeed(0), ncarSpeed(0) {}

        ~Organizer() {

        Patient* temp;
        while (!AllPatients.isEmpty()) {
            AllPatients.dequeue(temp);
            delete temp;
        }
        while (!CancellationList.isEmpty()) {
            CancellationList.dequeue(temp);
            delete temp;
        }
        while (!FinishedList.isEmpty()) {
            FinishedList.dequeue(temp);
            delete temp;
        }


        if (AllHospitals) {
            for (int i = 0; i < numHospitals; ++i) {
                delete AllHospitals[i];
            }
            delete[] AllHospitals;
        }


        if (distanceMatrix) {
            for (int i = 0; i < numHospitals; ++i) {
                delete[] distanceMatrix[i];
            }
            delete[] distanceMatrix;
        }
    }


    void load(const string& filename) {
        ifstream InputFile(filename);

        if (!InputFile.is_open()) {
            cerr << "Error: Unable to open input file!" << endl;
            return;
        }

        string line;


        getline(InputFile, line);
        numHospitals = stoi(line);


        getline(InputFile, line);
        istringstream stream1(line);
        stream1 >> scarSpeed >> ncarSpeed;


        distanceMatrix = new int* [numHospitals];
        for (int i = 0; i < numHospitals; i++) {
            distanceMatrix[i] = new int[numHospitals];
        }
        for (int i = 0; i < numHospitals; i++) {
            getline(InputFile, line);
            istringstream stream2(line);
            for (int j = 0; j < numHospitals; j++) {
                stream2 >> distanceMatrix[i][j];
            }
        }


        AllHospitals = new Hospital * [numHospitals];
        for (int i = 0; i < numHospitals; i++) {
            getline(InputFile, line);
            istringstream stream3(line);
            int numSCars, numNCars;
            stream3 >> numSCars >> numNCars;
            AllHospitals[i] = new Hospital();
            AllHospitals[i]->setID(i + 1);
            AllHospitals[i]->setFreeSC(numSCars);
            AllHospitals[i]->setFreeNC(numNCars);


            for (int j = 0; j < numSCars; j++) {
                Car* scar = new Car(scarSpeed, 1, j + 1, i + 1);
                AllHospitals[i]->addSCar(scar);
            }


            for (int j = 0; j < numNCars; j++) {
                Car* ncar = new Car(ncarSpeed, 0, j + 1, i + 1);
                AllHospitals[i]->addNCar(ncar);
            }
        }

        getline(InputFile, line);
        istringstream stream4(line);
        int numRequests;
        stream4 >> numRequests;

        for (int i = 0; i < numRequests; i++) {
            getline(InputFile, line);
            istringstream stream5(line);

            string type;
            int requestTime, pid, hid, distance, severity = 0;
            stream5 >> type >> requestTime >> pid >> hid >> distance;

            Patient* patient = nullptr;
            if (type == "NP") {
                patient = new NP(requestTime, pid, hid, distance);
            }
            else if (type == "SP") {
                patient = new SP(requestTime, pid, hid, distance);
            }
            else if (type == "EP") {
                stream5 >> severity;
                patient = new EP(requestTime, pid, hid, distance, severity);
            }
            AllPatients.enqueue(patient);
        }


        getline(InputFile, line);
        istringstream stream6(line);
        int numCancellations;
        stream6 >> numCancellations;

        for (int i = 0; i < numCancellations; i++) {
            getline(InputFile, line);
            istringstream stream7(line);
            int pid, hid, cancelTime;
            stream7 >> pid >> hid >> cancelTime;

            Patient* cancelRequest = new Patient();
            cancelRequest->setPID(pid);
            cancelRequest->setHID(hid);
            cancelRequest->setCancelTime(cancelTime);
            CancellationList.enqueue(cancelRequest);
        }



        getline(InputFile, line);
        istringstream stream10(line);
        stream10 >> outcarfail;

        getline(InputFile, line);
        istringstream stream11(line);
        stream11 >> checkuptime;

        InputFile.close();
    }
    LinkedQueue<Patient*> getFinishedList() { return FinishedList; }

    int getNumHospitals() const { return numHospitals; }

    int** getDistanceMatrix() const { return distanceMatrix; }

    Hospital* getHospital(int index) const { return AllHospitals[index]; }

    LinkedQueue<Patient*>& getAllPatients() { return AllPatients; }

    LinkedQueue<Patient*>& getCancellationList() { return CancellationList; }


    int countNP()
    {
        int countNP = 0;
        for (int i = 0; i < numHospitals; i++)
        {
            countNP += AllHospitals[i]->getNPList().count();
        }
        return countNP;
    }
    int countSP()
    {
        int countSP = 0;
        for (int i = 0; i < numHospitals; i++)
        {
            countSP += AllHospitals[i]->getSPList().count();
        }
        return countSP;

    }
    int countEP()
    {
        int countEP = 0;
        for (int i = 0; i < numHospitals; i++)
        {
            countEP += AllHospitals[i]->getEPList().count();
        }
        return countEP;

    }
    int countSC() {
        int count = 0;
        for (int i = 0; i < numHospitals; i++) {
            count += AllHospitals[i]->getSCars().count();
        }
        return count;
    }

    int countNC() {
        int count = 0;
        for (int i = 0; i < numHospitals; i++) {
            count += AllHospitals[i]->getNCars().count();
        }
        return count;
    }

    int avgbusytime()
    {
        int count = 0;
        for (int i = 0; i < numHospitals; i++)
        {
            count += AllHospitals[i]->getBusyTime();
        }
        return ((count / countNC() + countSC()) * 100);
    }
    int avgutilization()
    {
        return ((avgbusytime() / (SimulationTime::getTimeStep() * countNC() + countSC() ) ) * 100);
    }
    int avgwaittime() {
        int totalWaitTime = 0;
        int totalPatients = 0;

        for (int i = 0; i < numHospitals; i++) {
            totalWaitTime += AllHospitals[i]->getWaitTime();
            totalPatients += AllHospitals[i]->getNPList().count() +
                AllHospitals[i]->getSPList().count() +
                AllHospitals[i]->getEPList().count();
        }

        return (totalPatients > 0) ? (totalWaitTime / totalPatients) : 0;
    }


    int TotalCars() {
        return countNC() + countSC();
    }

    int TotalPatients() {
        return countEP() + countNP() + countSP();
    }



    int findNearestAvailableHospital(int patientHospitalID) {
        int nearestHospitalIndex = -1;
        int minDistance = INT_MAX;

        for (int i = 0; i < numHospitals; i++) {
            if (i != patientHospitalID - 1 && !AllHospitals[i]->GetFail()) {
                if (distanceMatrix[patientHospitalID - 1][i] < minDistance) {
                    nearestHospitalIndex = i;
                    minDistance = distanceMatrix[patientHospitalID - 1][i];
                }
            }
        }
        return nearestHospitalIndex;
    }

    //assign patients
    void processPatientRequests() {
        Patient* currentPatient = nullptr;
        LinkedQueue<Patient*> tempQueue;
        int currentTimestep = SimulationTime::getTimeStep();


        while (!AllPatients.isEmpty()) {
            AllPatients.dequeue(currentPatient);
            if (currentPatient->getRequestTime() == currentTimestep) {

                int assignedHospitalID = currentPatient->getHID() - 1;
                if (assignedHospitalID < 0 || assignedHospitalID >= numHospitals || AllHospitals[assignedHospitalID]->GetFail()) {

                    assignedHospitalID = findNearestAvailableHospital(currentPatient->getHID());
                    if (assignedHospitalID == -1) {
                        cerr << "Error: No available hospitals for patient " << currentPatient->getPID() << endl;
                        tempQueue.enqueue(currentPatient); 
                        continue;
                    }
                    currentPatient->setHID(assignedHospitalID + 1);
                }

                Hospital* hospital = AllHospitals[assignedHospitalID];
                if (EP* epPatient = dynamic_cast<EP*>(currentPatient)) {

                    hospital->addEP(epPatient);
                }
                else if (SP* spPatient = dynamic_cast<SP*>(currentPatient)) {

                    hospital->addSP(spPatient);
                }
                else if (NP* npPatient = dynamic_cast<NP*>(currentPatient)) {

                    hospital->addNP(npPatient);
                }
            }
            else {

                tempQueue.enqueue(currentPatient);
            }
        }


        while (!tempQueue.isEmpty()) {
            tempQueue.dequeue(currentPatient);
            AllPatients.enqueue(currentPatient);
        }


        assignPatientsToCars();
    }

    void assignPatientsToCars() {
        for (int i = 0; i < numHospitals; i++) {
            Hospital* hospital = AllHospitals[i];

            while (!hospital->isEmpty()) {
                Car* availableCar = nullptr;
                Patient* patient = nullptr;


                if (!hospital->getEPList().isEmpty() && !hospital->getNCars().isEmpty()) {
                    hospital->getNCars().dequeue(availableCar);
                    hospital->RemoveEP(reinterpret_cast<EP*&>(patient));
                }
                else if (!hospital->getEPList().isEmpty() && !hospital->getSCars().isEmpty()) {
                    hospital->getSCars().dequeue(availableCar);
                    hospital->RemoveEP(reinterpret_cast<EP*&>(patient));
                }


                else if (!hospital->getSPList().isEmpty() && !hospital->getSCars().isEmpty()) {
                    hospital->getSCars().dequeue(availableCar);
                    hospital->RemoveSP(reinterpret_cast<SP*&>(patient));
                }


                else if (!hospital->getNPList().isEmpty() && !hospital->getNCars().isEmpty()) {
                    hospital->getNCars().dequeue(availableCar);
                    hospital->RemoveNP(reinterpret_cast<NP*&>(patient));
                }


                if (!availableCar || !patient) {
                    break;
                }


                availableCar->assignPatient(patient);
                OutCars.enqueue(availableCar, availableCar->getFinish_time());
            }
        }
    }

    void handleCancellationRequests() {
        Patient* currentCancellation = nullptr;
        LinkedQueue<Patient*> tempQueue;
        int currentTimestep = SimulationTime::getTimeStep();


        while (!CancellationList.isEmpty()) {
            CancellationList.dequeue(currentCancellation);

            if (currentCancellation->getCancelTime() == currentTimestep) {

                int hospitalID = currentCancellation->getHID() - 1;

                if (hospitalID < 0 || hospitalID >= numHospitals || AllHospitals[hospitalID]->GetFail()) {

                    cerr << "Error: Invalid or failed hospital for cancellation request of patient " << currentCancellation->getPID() << endl;
                    delete currentCancellation; 
                    continue;
                }

                Hospital* hospital = AllHospitals[hospitalID];


                if (NP* npPatient = dynamic_cast<NP*>(currentCancellation)) {
                    if (!hospital->RemoveNP(npPatient)) {

                        handleCarCancellation(npPatient);
                    }
                    else {
                        delete npPatient;
                    }
                }
                else if (SP* spPatient = dynamic_cast<SP*>(currentCancellation)) {
                    if (!hospital->RemoveSP(spPatient)) {
 
                        handleCarCancellation(spPatient);
                    }
                    else {
                        delete spPatient; 
                    }
                }
                else if (EP* epPatient = dynamic_cast<EP*>(currentCancellation)) {
                    if (!hospital->RemoveEP(epPatient)) {

                        handleCarCancellation(epPatient);
                    }
                    else {
                        delete epPatient; 
                    }
                }
            }
            else {
                tempQueue.enqueue(currentCancellation);
            }
        }

        while (!tempQueue.isEmpty()) {
            tempQueue.dequeue(currentCancellation);
            CancellationList.enqueue(currentCancellation);
        }
    }

    void handleCarCancellation(Patient* canceledPatient) {
        Car* assignedCar = nullptr;
        int priority;

        priQueue<Car*> tempOutCars;

        while (OutCars.dequeue(assignedCar, priority)) {
            if (assignedCar->getPatient() && assignedCar->getPatient()->getPID() == canceledPatient->getPID()) {
                assignedCar->removePatient(); 
                CheckupList.enqueue(assignedCar); 
                nooffailedcars++; 
            }
            else {

                tempOutCars.enqueue(assignedCar, priority);
            }
        }


        while (tempOutCars.dequeue(assignedCar, priority)) {
            OutCars.enqueue(assignedCar, priority);
        }


        delete canceledPatient;
    }


    void handleCarReturns() {
        Car* currentCar = nullptr;
        int priority;


        priQueue<Car*> tempOutCars;


        while (OutCars.dequeue(currentCar, priority)) {
            if (SimulationTime::getTimeStep() >= currentCar->getFinish_time()) {

                currentCar->removePatient(); 

                int returnTime = SimulationTime::getTimeStep() +
                    ceil(static_cast<double>(distanceMatrix[currentCar->getHID() - 1][currentCar->getHID() - 1]) /
                        static_cast<double>(currentCar->getSpeed()));

                currentCar->setFinishTime(returnTime); 
                BackCars.enqueue(currentCar, -returnTime); 
            }
            else {
                tempOutCars.enqueue(currentCar, priority);
            }
        }
        while (tempOutCars.dequeue(currentCar, priority)) {
            OutCars.enqueue(currentCar, priority);
        }
    }

    void processReturnedCars() {
        Car* returningCar = nullptr;
        int priority;


        priQueue<Car*> tempBackCars;

        while (BackCars.dequeue(returningCar, priority)) {
            if (SimulationTime::getTimeStep() >= returningCar->getFinish_time()) {
                Patient* finishedPatient = returningCar->getPatient();

                if (finishedPatient) {

                    finishedPatient->setFinishTime(SimulationTime::getTimeStep());
                    FinishedList.enqueue(finishedPatient);
                    returningCar->removePatient();
                }

                Hospital* homeHospital = AllHospitals[returningCar->getHID() - 1];
                if (returningCar->gettype() == 0) {
                    homeHospital->addNCar(returningCar);
                }
                else if (returningCar->gettype() == 1) {
                    homeHospital->addSCar(returningCar);
                }
            }
            else {
                tempBackCars.enqueue(returningCar, priority);
            }
        }


        while (tempBackCars.dequeue(returningCar, priority)) {
            BackCars.enqueue(returningCar, priority);
        }
    }

    void handleOutCarFailures() {
        if (OutCars.isEmpty()) {
            return; 
        }

        std::srand(static_cast<unsigned int>(std::time(0)));
        int randomValue = rand() % 100;  

        if (randomValue >= outcarfail) {
            return; 
        }


        Car* failingCar = nullptr;
        int priority;
        int selectedIndex = rand() % OutCars.count();
        int currentIndex = 0;

        priQueue<Car*> tempOutCars;


        while (OutCars.dequeue(failingCar, priority)) {
            if (currentIndex == selectedIndex) {

                failingCar->setFail();


                Patient* failedPatient = failingCar->getPatient();
                if (failedPatient) {

                    LinkedQueue<Patient*> tempAllPatients;
                    Patient* tempPatient;

                    while (!AllPatients.isEmpty()) {
                        AllPatients.dequeue(tempPatient);
                        tempAllPatients.enqueue(tempPatient);
                    }

                    AllPatients.enqueue(failedPatient);

                    while (!tempAllPatients.isEmpty()) {
                        tempAllPatients.dequeue(tempPatient);
                        AllPatients.enqueue(tempPatient);
                    }

                    failingCar->removePatient();
                }


                BackCars.enqueue(failingCar, -failingCar->getFinish_time());


                CheckupList.enqueue(failingCar);

                nooffailedcars++;
            }
            else {

                tempOutCars.enqueue(failingCar, priority);
            }
            currentIndex++;
        }

        while (tempOutCars.dequeue(failingCar, priority)) {
            OutCars.enqueue(failingCar, priority);
        }
    }

    void simulate() {
        SimulationTime::resetTimeStep();



        while (!AllPatients.isEmpty() || !OutCars.isEmpty() || !BackCars.isEmpty() || !CancellationList.isEmpty()) {

            cout << "Timestep: " << SimulationTime::getTimeStep() << endl;


            processPatientRequests();


            handleCancellationRequests();


            processReturnedCars();


            handleCarReturns();


            handleOutCarFailures();


            while (!CheckupList.isEmpty()) {
                Car* car = nullptr;
                CheckupList.dequeue(car);


                if (SimulationTime::getTimeStep() >= car->getFinish_time() + checkuptime) {

                    Hospital* homeHospital = AllHospitals[car->getHID() - 1];
                    if (car->gettype() == 0) {
                        homeHospital->addNCar(car);
                    }
                    else {
                        homeHospital->addSCar(car);
                    }
                }
                else {

                    CheckupList.enqueue(car);
                }
            }


            SimulationTime::incrementTimeStep();
        }


        cout << "Simulation complete. Generating output file..." << endl;
        generateOutputFile();
    }


    void generateOutputFile() {
        ofstream outputFile("output.txt");
        if (!outputFile.is_open()) {
            cerr << "Error: Unable to create output file!" << endl;
            return;
        }


        Patient* finishedPatient = nullptr;
        outputFile << "FT PID QT WT" << endl;
        while (!FinishedList.isEmpty()) {
            FinishedList.dequeue(finishedPatient);
            outputFile << finishedPatient->getFinishTime() << " "
                << finishedPatient->getPID() << " "
                << finishedPatient->getRequestTime() << " "
                << finishedPatient->getWaitTime() << endl;
            delete finishedPatient;
        }


        outputFile << endl;
        outputFile << "patients: " << TotalPatients() << " [NP: " << countNP()
            << ", SP: " << countSP() << ", EP: " << countEP() << "]" << endl;
        outputFile << "Hospitals: " << numHospitals << endl;
        outputFile << "cars: " << TotalCars() << " [SCars: " << countSC()
            << ", NCars: " << countNC() << "]" << endl;
        outputFile << "Avg wait time: " << avgwaittime() << endl;
        outputFile << "Avg busy time: " << avgbusytime() << endl;
        outputFile << "Avg utilization: " << avgutilization() << "%" << endl;

        outputFile.close();
        cout << "Output file generated: output.txt" << endl;
    }

};

#endif