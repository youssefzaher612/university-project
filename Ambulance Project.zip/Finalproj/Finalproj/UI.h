#pragma once
#include <iostream>
#include <string>
#include "Organizer.h" 

using namespace std;

class UI {
private:
    Organizer* organizer;
public:
    UI(Organizer* org);
    void displayMainMenu();
    void runInteractiveMode();
    void runSilentMode();
    void start();
};


UI::UI(Organizer* org) : organizer(org) {}


void UI::displayMainMenu() {
    cout << "========== Ambulance Management System ==========" << endl;
    cout << "1. Run Simulation in Interactive Mode" << endl;
    cout << "2. Run Simulation in Silent Mode" << endl;
    cout << "3. Exit" << endl;
    cout << "=================================================" << endl;
    cout << "Enter your choice: ";
}


void UI::runInteractiveMode() {
    cout << "Interactive Mode Running... Press ENTER to proceed to the next timestep." << endl;

    while (!organizer->getAllPatients().isEmpty() ||
        !organizer->getCancellationList().isEmpty() ||
        !organizer->getFinishedList().isEmpty()) {
        cout << "-------------------------------------------------" << endl;
        cout << "Current Timestep: " << SimulationTime::getTimeStep() << endl;


        for (int i = 0; i < organizer->getNumHospitals(); i++) {
            Hospital* hospital = organizer->getHospital(i);
            cout << "=========== Hospital #" << hospital->getHID() << " ===========" << endl;
            hospital->printAll();
            cout << "==============================================" << endl;
        }

        cout << "Press ENTER to proceed to the next timestep..." << endl;
        cin.ignore();


        SimulationTime::incrementTimeStep();
        organizer->simulate();
    }

    cout << "Simulation completed. Output file generated." << endl;
}


void UI::runSilentMode() {
    cout << "Silent Mode Running... Simulation Starts..." << endl;
    organizer->simulate();
    cout << "Simulation Ends. Output file generated." << endl;
}


void UI::start() {
    while (true) {
        displayMainMenu();
        int choice;
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1:
            runInteractiveMode();
            break;
        case 2:
            runSilentMode();
            break;
        case 3:
            cout << "Exiting Program..." << endl;
            return;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    }
}
