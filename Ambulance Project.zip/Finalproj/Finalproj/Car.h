#pragma once
#include <iostream>
#include "Patient.h"
#include "SimulationTime.h"
using namespace std;
class Car
{
           
    int status; // 0ready 1 assigned -1loaded
    int speed;
    int busyTime;
    Patient* assigned_patient;

    int pickup_time;
    int finish_time;
    int current_time; 

    int assignment_time;

    int id;
    int hid;
    // 0 for NC, 1 for SC
    int type;
    bool failure = false;

public:
    Car() {

        status = 0;
        busyTime = 0;
        speed = 0;
        assigned_patient = nullptr;

        pickup_time = 0;
        finish_time = 0;
        id = 0;
        assignment_time = 0;
        hid = 0;
        type = 0;
    }
    Car(int speed, int type, int id, int hid) {
        status = 0;
        this->speed = speed;
        this->type = type;
        this->id = id;
        this->hid = hid;
        assigned_patient = nullptr;

        pickup_time = 0;
        finish_time = 0;
        assignment_time = 0;
    }
    ~Car()
    {

    }


    void setSpeed(int speed) {
        this->speed = speed;
    }
    void setBusyTime(int busyTime) { this->busyTime += busyTime; } 
    void setAssignTime(int assignment_time) { this->assignment_time = assignment_time; }
    void setPatient(Patient* patient) { this->assigned_patient = patient; }
    void setPickupTime(int pickup_time) { this->pickup_time = pickup_time; }
    void setFinishTime(int finish_time) { this->finish_time = finish_time; }
    void setHID(int hid) {
        this->hid = hid;
    }
    void setType(int type) {
        this->type = type;
    }
    void setStatus(int status) {
        this->status = status;
    }
    void setID(int id) {
        this->id = id;
    }

    void setFail() {
        failure = true;
    }
    bool GetFail()
    {
        return failure;
    }


    int getSpeed() const {
        return speed;
    }
    int getBusyTime() const { return busyTime; }
    int getAssignTime() const { return assignment_time; }
    Patient* getPatient() const {
        return assigned_patient;
    }
    int getPickup_time() const {
        return pickup_time;
    }
    int getFinish_time() const {
        return finish_time;
    }
    int getID() const {
        return id;
    }
    int gettype() const {
        return type;
    }
    int getHID() const {
        return hid;
    }
    int getStatus() const {
        return status;
    }

    int getTimeStep() {
        return SimulationTime::getTimeStep();
    }


    
    void assignPatient(Patient* patient) {
        pickup_time = getTimeStep() + ceil(double(patient->getDistance()) / double(speed));
        patient->setPickupTime(pickup_time);
        finish_time = pickup_time + ceil(double(patient->getDistance()) / double(speed));
        patient->setFinishTime(finish_time);
        setPatient(patient);
        setStatus(1);
    }
    

    void print() {
        if (type == 1) {
            cout << "S";
        }
        else {
            cout << "N";
        }
        if (assigned_patient) {
            cout << id << "_H" << hid << "_P" << assigned_patient->getPID();
        }
        else {
            cout << id << "_H" << hid;
        }
    }


    //status
    void removePatient() {
        assigned_patient = nullptr;
        setStatus(0);
        pickup_time = 0;
        finish_time = 0;
    }

};