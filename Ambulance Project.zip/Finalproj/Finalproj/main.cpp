#include "Organizer.h"
#include "UI.h"

int main() {
    Organizer organizer;
    organizer.load("input.txt"); // Load input data

    UI ui(&organizer);
    ui.start();

    return 0;
}
