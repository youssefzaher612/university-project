#pragma once

class SimulationTime {
public:
    static int getTimeStep();
    static void incrementTimeStep();
    static void resetTimeStep();
    static void setTimeStep(int t);
private:
    static int timeStep;
};

int SimulationTime::timeStep = 0;

int SimulationTime::getTimeStep() {
    return timeStep;
}

void SimulationTime::setTimeStep(int t) {
    timeStep = t;
}

void SimulationTime::incrementTimeStep() {
    ++timeStep;
}

void SimulationTime::resetTimeStep() {
    timeStep = 0;
}
